# Agent Dashboard

React dashboard to monitor Amazon Connect agents.